# Product Surfaces

The UI should expose the system without pretending it is more complete than it is.

## Public

Discover · Build · Connect · Earn · Explore · Docs · Machine interface

## Private Founder control plane

System map · Agent workshop · Capability library · Opportunity engine · Revenue ledger · Command interface · Security · Audit · Services · Settings

A sensitive dashboard is never made private by hiding it in the UI. It requires server-side identity and authorization.

The human interface and machine interface are complementary: humans get clarity; machines get precise discovery metadata.
