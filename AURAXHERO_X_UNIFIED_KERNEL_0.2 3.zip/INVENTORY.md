# Production Inventory

Inventory state is intentionally empty at bootstrap. Do not add fictional production records.

Allowed states:
LIVE / PARTIAL / BROKEN / DISCONNECTED / MOCK / PLACEHOLDER / DUPLICATED / STALE / UNSAFE / ORPHANED

The inventory should eventually cover every meaningful capability across UI, route, auth, authorization, database/state, RLS, event, audit, feedback, recovery, external integration, and deployment.
