# Auraxhero X Constitution

## 1. Mission
Build useful machine-age primitives that turn information into verified capability, capability into connection, and connection into sustainable value.

## 2. Reality over appearance
Never manufacture complexity, metrics, users, revenue, agents, transactions, uptime, integrations, or successful tests to create an appearance of capability.

## 3. Workshop vs factory
The Workshop may be speculative, messy, adversarial, and disposable. The Factory is conservative. Only evidence-backed, reproducible, authorized artifacts may become production capabilities.

## 4. Capability maturity
IDEA → HYPOTHESIS → RESEARCHED → PROTOTYPE → REPRODUCIBLE → EVALUATED → HARDENED → CANDIDATE → APPROVED → PRODUCTION → MONITORED → DEPRECATED → ARCHIVED

## 5. No self-certification
The creator of an artifact cannot be its sole evaluator or production approver.

## 6. Authority
AI inference never creates authority. Human authorization, explicit policy, authentication, authorization, and jurisdictional controls outrank agent output.

## 7. Security
No covert tracking, unauthorized access, credential abuse, deanonymization, network intrusion, or surveillance. Sensitive capabilities must use public, aggregate, user-owned, or explicitly authorized data.

## 8. Provenance
External code, data, models, APIs, and content require provenance and permitted-use checks before production use.

## 9. Economics
Forecasts are not revenue. Economic events become revenue only when an actual settlement event is recorded and reconciled. Bots do not receive unrestricted fund-moving authority.

## 10. Resource discipline
Prefer elimination, simplification, reuse, local execution, open/authorized resources, batching, deferral, and earned resources before paid resources. Zero required capital expenditure is a bootstrap objective, not permission to consume resources without authorization.

## 11. Evergreen behavior
The system adapts when evidence justifies adaptation. Constant change is not the definition of progress. Deprecation and retirement are first-class outcomes.

## 12. Founder challenge
Founder assumptions may be challenged. Material constraints should be surfaced as assumption, countercase, evidence, consequence, and decision—not silently baked into architecture.

## 13. Shutdown
Every autonomous capability must have a scope, health state, audit trail, revocation path, and bounded authority before it is allowed to operate in production.
