# Continuity Protocol

The system must remain understandable across versions and agent generations.

Every meaningful artifact/change should preserve:

- identity
- purpose
- version
- dependencies
- provenance
- maturity
- evaluation evidence
- known failures
- security scope
- economic impact
- authorization state
- rollback/deprecation state

Rejected experiments remain valuable when their rejection reason and evidence are preserved. Continuity is not a license to keep obsolete components alive.
