# Auraxhero X — Unified Kernel

Auraxhero X is a machine-age ecosystem for discovering unmet needs, composing capabilities, building and evaluating machine tools, connecting humans and machines, and creating durable economic value.

This repository is the **single source of truth for the Auraxhero X codebase**. It is intentionally small at bootstrap and intentionally truthful: no fake users, agents, revenue, transactions, production services, or health claims are created merely to make the interface look complete.

## Core loop

OBSERVE → QUESTION → DISCOVER → SYNTHESIZE → BUILD → CRITIQUE → TEST → VERIFY → HARDEN → PUBLISH → MONITOR → LEARN

## Operating principle

**Autonomous creativity. Controlled authority.**

The system may explore aggressively. Production promotion, security boundaries, financial authority, legal/provenance decisions, and governance remain explicitly controlled.

## Bootstrap status

- Next.js + React + TypeScript
- Local development requires no paid service
- Public machine-discovery endpoint included
- Founder surface exists as an explicit authentication boundary, not a fake login
- Capability/evaluation/resource/economic primitives are real code, with no fabricated production state
- Persistence, real authentication/MFA, agent execution, payment adapters, and production deployment are deliberately not claimed until wired and verified

## First repository/deployment rule

This repository should be created privately and connected to a dedicated Vercel project. Do not merge it into Brindlewick or assume the existing Netlify `auraxhero` shell is the Auraxhero X source repository.
