# Agent System

Agents are workers inside the ecosystem, not the authority over it.

## Roles

ARTISAN creates. SKEPTIC attacks assumptions. ARCHITECT checks system fit. SECURITY checks abuse and boundaries. PROVENANCE checks permitted use and attribution. ECONOMIC evaluates demand and unit economics. ADVERSARIAL attempts controlled failure. EVALUATOR verifies. CURATOR decides promotion under policy. MAINTAINER monitors. OBSERVER records. FORECASTER models possible futures.

## Required agent record

Every production agent needs an ID, role, status, scope, authority, creation record, audit trail, health state, and revocation path.

## Rule

The builder cannot be the sole judge of its own work. Agent learning cannot silently rewrite security, financial, legal, or governance boundaries.
