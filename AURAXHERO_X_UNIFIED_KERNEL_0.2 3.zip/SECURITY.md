# Security Boundary

## Non-negotiables

- Authentication is distinct from authorization.
- URL parameters, local storage, role text, UI visibility, or AI inference never grant privilege.
- Sensitive founder routes require server-side authentication and authorization plus MFA/passkey support when implemented.
- Agents operate under explicit scopes and cannot expand their own authority.
- Financial actions require explicit economic/settlement boundaries and reconciliation.
- External inputs are treated as untrusted.
- Code/data/model ingestion requires provenance, license/terms review, dependency/security review, and reproducibility checks.
- Shutdown/revocation must be possible per autonomous capability.

## Sensitive discovery

Address sleuthing, UID tracking, IP analysis, Wi-Fi mapping, and similar capabilities are restricted to public, aggregate, user-owned, or explicitly authorized data. No covert tracking or unauthorized network access is part of the kernel.

## Founder boundary

`/founder` is private control-plane territory. The current bootstrap deliberately does not pretend that authentication exists. Production implementation must establish identity, session validation, authorization, MFA/AAL2 or equivalent, audit logging, and recovery before exposing sensitive state.
