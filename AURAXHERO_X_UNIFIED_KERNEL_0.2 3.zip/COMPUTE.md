# Compute Plane

Auraxhero X is hardware/provider agnostic.

The system should route workloads according to the least-resource adequate substrate using requirements such as memory, latency, throughput, precision, framework, security, geography, and cost.

Potential substrates include local CPU/GPU/NPU, NVIDIA, AMD, Google TPU, AWS Trainium, Cerebras, custom accelerators, edge devices, and future authorized providers. This is an adapter space, not a commitment to a particular vendor.

The system continuously evaluates adequacy, software support, memory/interconnect constraints, energy, latency, availability, and price.

The first optimization question is: **Can we avoid running this workload at all?**
